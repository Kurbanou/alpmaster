<?php
    echo "Hi!";
?>